# ************************************************************
# Sequel Pro SQL dump
# Version 4631
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.0.34-MariaDB)
# Database: graph
# Generation Time: 2019-02-23 18:00:39 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table city
# ------------------------------------------------------------

CREATE TABLE `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `name` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;

INSERT INTO `city` (`id`, `latitude`, `longitude`, `name`)
VALUES
	(1,59.3442327,18.0456211,'Vasastan'),
	(2,57.6952191,11.9924641,'Liseberg'),
	(3,26.1723065,-80.1319893,'Oakland Park'),
	(4,28.6277767,-81.3631243,'Maitland'),
	(5,32.1656221,-82.9000751,'Georgia'),
	(6,52.0115205,4.7104633,'Gouda'),
	(7,21.349663,92.0420152,'Himchari'),
	(8,22.4943822,92.2212071,'Kaptai'),
	(9,23.7791954,90.3736584,'Agargaon'),
	(10,23.7850498,90.41134,'Karail'),
	(11,23.593449,91.0011902,'Debidwar'),
	(12,24.3095344,91.7314902,'Moulvibazar'),
	(13,23.0488146,89.8879304,'Gopalganj'),
	(14,22.845641,89.5403279,'Jessore');

/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table path
# ------------------------------------------------------------

CREATE TABLE `path` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `container_size` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `transport_type` varchar(256) DEFAULT NULL,
  `from_city` int(11) DEFAULT NULL,
  `to_city` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1kt3142m2g5ibivv28b1m7buu` (`from_city`),
  KEY `FK2bb4upjtl1psoav6iutywsmwc` (`to_city`),
  CONSTRAINT `FK1kt3142m2g5ibivv28b1m7buu` FOREIGN KEY (`from_city`) REFERENCES `city` (`id`),
  CONSTRAINT `FK2bb4upjtl1psoav6iutywsmwc` FOREIGN KEY (`to_city`) REFERENCES `city` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `path` WRITE;
/*!40000 ALTER TABLE `path` DISABLE KEYS */;

INSERT INTO `path` (`id`, `container_size`, `cost`, `duration`, `transport_type`, `from_city`, `to_city`)
VALUES
	(1,20,480,1,'Road',1,2),
	(2,20,2050,1,'Air',1,2),
	(3,40,680,1,'Road',1,2),
	(4,40,3050,1,'Air',1,2),
	(5,20,1673,22,'Ocean',2,3),
	(6,40,2550,22,'Ocean',2,3),
	(7,20,650,1,'Road',3,4),
	(8,20,2050,1,'Air',3,4),
	(9,40,950,1,'Road',3,4),
	(10,40,3050,1,'Air',3,4),
	(11,20,1815,23,'Ocean',2,5),
	(12,40,2650,23,'Ocean',2,5),
	(13,20,650,1,'Road',5,4),
	(14,20,2050,1,'Air',5,4),
	(15,40,950,1,'Road',5,4),
	(16,40,3050,1,'Air',5,4),
	(17,20,1480,3,'Road',1,6),
	(18,20,2550,1,'Air',1,6),
	(19,40,2650,3,'Road',1,6),
	(20,40,3550,1,'Air',1,6),
	(21,20,1673,18,'Ocean',6,3),
	(22,40,2650,18,'Ocean',6,3),
	(23,20,100,1,'Road',7,8),
	(24,20,112,1,'Road',8,9),
	(25,20,115,1,'Road',8,10),
	(26,20,135,1,'Road',7,11),
	(27,20,82,1,'Road',11,9),
	(28,20,85,1,'Road',11,10),
	(29,40,130,1,'Road',7,8),
	(30,40,142,1,'Road',8,9),
	(31,40,145,1,'Road',8,10),
	(32,40,165,1,'Road',7,11),
	(33,40,112,1,'Road',11,9),
	(34,40,115,1,'Road',11,10),
	(35,20,120,1,'Road',13,12);

/*!40000 ALTER TABLE `path` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table preference
# ------------------------------------------------------------

CREATE TABLE `preference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1024) DEFAULT NULL,
  `value` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `preference` WRITE;
/*!40000 ALTER TABLE `preference` DISABLE KEYS */;

INSERT INTO `preference` (`id`, `name`, `value`)
VALUES
	(1,'Google geocode API Key','AIzaSyC8-HBw08K4PVZpXE5PtGIPKrjU_t1Nuhg');

/*!40000 ALTER TABLE `preference` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
